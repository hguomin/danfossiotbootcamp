﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PerfSensor
{
    public class PerfCounter
    {
        PerformanceCounter _cpuCounter;
        PerformanceCounter _availableMemoryCounter;

        public double CpuUsage 
        { 
            get
            {
                return Math.Round(_cpuCounter.NextValue(), 2);
            } 
        }

        public double MemoryAvailable
        {
            get
            {
                return Math.Round(_availableMemoryCounter.NextValue()/1024, 2);
            }
        }

        private HttpClient _client;
        private readonly object _hostLock = new object();
        private string _host = "www.baidu.com";
        public long NetworkWebLatency
        {
            get
            {
                return GetWebAccessLatency().Result;
            }
        }

        public long NetworkPingLatency
        {
            get
            {
                return GetPingLatency();
            }
        }

        public string NetworkHostname
        {
            set
            {
                lock(_hostLock)
                {
                    _host = value;
                }
            }
            get
            {
                lock(_hostLock)
                {
                    return _host;
                }
            }
        }

        public PerfCounter()
        {
            _cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
            _availableMemoryCounter = new PerformanceCounter("Memory", "Available MBytes", String.Empty);

            _client = new HttpClient();
        }

        private async Task<long> GetWebAccessLatency()
        {
            string url = $"https://{NetworkHostname}";

            using (var request = new HttpRequestMessage(HttpMethod.Get, url))
            {
                Stopwatch sw = new Stopwatch();
                sw.Start();
                var response = await _client.SendAsync(request, HttpCompletionOption.ResponseContentRead, CancellationToken.None).ConfigureAwait(false);
                sw.Stop();
                if (response.IsSuccessStatusCode)
                {
                    return sw.ElapsedMilliseconds;
                }

                return 0;
            }
        }

        private long GetPingLatency()
        {
            string hostname = NetworkHostname;

            Ping pingSender = new Ping();
            PingOptions options = new PingOptions();

            options.DontFragment = true;

            string data = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
            byte[] buffer = Encoding.ASCII.GetBytes(data);
            int timeout = 1200;
            PingReply reply = pingSender.Send(hostname, timeout, buffer, options);

            if (reply.Status == IPStatus.Success)
            {
                return reply.RoundtripTime;
            }
            return 0;
        }
    }
}
