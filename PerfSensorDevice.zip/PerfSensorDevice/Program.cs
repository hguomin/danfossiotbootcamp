﻿//
//By Guomin Huang //2019.12.08
//

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

//TASK-0: add libraries
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;

namespace PerfSensor
{
    public class Program
    {
        //TASK-0: copy you device connection here
        private static string iothubDeviceConnectionString = "Input your device connection string here.";

        private static DeviceClient deviceClient;

        private static int telemetryInterval = 1000;
        private static object telemetryIntervalLock = new object();

        private static PerfCounter perfCounter = new PerfCounter();

        public static void Main(string[] args)
        {
            MainAsync().Wait();

            Console.ReadLine(); 

        }

        private static async Task MainAsync()
        {
            Console.WriteLine("You device is running...\n");
            //TASK-1: create device client from connection string


            //TASK-3: register device method for command


            //TASK-4: register device method for SetNetworkLatencyTestTargetHost


            List<Task> tasks = new List<Task>();
            //TASK-2: Send device telemetry 

            //TASK-5: receive cloud to device message

            Task.WaitAll(tasks.ToArray());
        }

        //TASK-2: Send device messgage: SendDeviceTelemetryAsync


        //TASK-3: Handle device command: SetTelemetryInterval


        //TASK-4: Handle device command: SetNetworkLatencyTestTargetHost


        //TASK-5: Receive cloud to device message: ReceiveDeviceMessage

    }
}